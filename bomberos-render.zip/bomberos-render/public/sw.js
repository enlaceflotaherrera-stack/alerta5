
const CACHE_NAME = "bomberos-render-v1";
const ASSETS = ["/","/index.html","/manifest.webmanifest","/icons/icon-192.png","/icons/icon-512.png",
  "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css","https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
];
self.addEventListener("install", e=>{ e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS))); self.skipWaiting(); });
self.addEventListener("activate", e=>{ e.waitUntil(caches.keys().then(keys=>Promise.all(keys.map(k=>k!==CACHE_NAME?caches.delete(k):null)))); self.clients.claim(); });
self.addEventListener("fetch", e=>{
  const url = new URL(e.request.url);
  if (url.pathname.startsWith("/socket.io/") || url.pathname.startsWith("/api/")) return;
  e.respondWith(fetch(e.request).then(r=>{ const copy=r.clone(); caches.open(CACHE_NAME).then(c=>c.put(e.request, copy)); return r; }).catch(()=>caches.match(e.request)));
});
self.addEventListener("push", e=>{
  let data={}; try{ data=e.data.json(); }catch{}
  const title=data.title||"🚨 Bomberos"; const options={ body:data.body||"", tag:data.tag||"bomberos", icon:"/icons/icon-192.png", badge:"/icons/icon-192.png" };
  e.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener("notificationclick", e=>{
  e.notification.close();
  e.waitUntil(clients.matchAll({type:"window"}).then(list=> list[0]?list[0].focus():clients.openWindow("/")));
});
